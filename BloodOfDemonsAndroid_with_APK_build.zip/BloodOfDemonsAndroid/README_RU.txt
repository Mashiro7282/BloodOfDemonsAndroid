КРОВЬ ДЕМОНОВ — Android-проект

Это исходный проект Android Studio. В текущей среде нет Android SDK и Gradle, поэтому готовый APK здесь не собран.

Как получить APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив.
3. В Android Studio выбери Open и укажи папку BloodOfDemonsAndroid.
4. Дождись синхронизации Gradle (нужен интернет для загрузки Android Gradle Plugin).
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Для установки на телефон перенеси app-debug.apk на Android и разреши установку приложений из выбранного источника.

Игра работает офлайн внутри WebView. Это первая играбельная версия: диалоги, выборы и несколько концовок.


АВТОСБОРКА APK ЧЕРЕЗ GITHUB ACTIONS:
В проект добавлен файл .github/workflows/build-apk.yml.
1. Создай пустой репозиторий на GitHub и загрузи туда содержимое этого проекта.
2. Открой вкладку Actions и запусти Build Android APK (или сделай push в main).
3. После успешной сборки скачай артефакт BloodOfDemons-debug-apk из завершённого запуска.
Это будет устанавливаемый debug APK.
